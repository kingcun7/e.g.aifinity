---
layout: layout.njk
title: Welcome to AIfinity
---

# Empower Your Workflow with AI

This is the placeholder homepage. Content will be generated via GPT-4 automation.
