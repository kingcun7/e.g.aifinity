module.exports = function(eleventyConfig) {
  eleventyConfig.addPassthroughCopy('robots.txt');
  eleventyConfig.addPassthroughCopy('netlify.toml');
  return {
    dir: {
      input: 'src',
      output: '_site'
    }
  };
};